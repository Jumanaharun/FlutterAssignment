package com.Assignment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
