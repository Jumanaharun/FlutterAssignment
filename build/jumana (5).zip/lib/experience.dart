import 'package:flutter/material.dart';

class Experience extends StatelessWidget {
  const Experience({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("My Experiences"),
      ),
      body: Column(
        children: [
          Text(
              "Since I was raised abroad, I grew up in a multi-cultural neighbourhood and befriended many foreign students. To overcome my stage fright, I used to join in debate and many stage presentations. I used to take part in various annual function and events as well to boost my confidence,  After moving to Bangladesh, I took up tutoring as my part-time job to be able to cope with new environment and people and also to gain more knowledge.")
        ],
      ),
    );
  }
}
