import 'dart:js';

import 'package:Assignment/education.dart';
import 'package:Assignment/experience.dart';
import 'package:Assignment/personal_info.dart';
import 'package:Assignment/skills.dart';
import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(
            child: Text("My Portfolio",
                style: TextStyle(
                    fontWeight: FontWeight.bold, color: Colors.white))),
        backgroundColor: Colors.blue,
      ),
      body: Center(
        child: Column(
          children: [
            Image.asset(
              "assets/images/jumana.jpg",
              width: 200,
              height: 200,
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Text(
                    "Jumana Mohammed Harun",
                    style: TextStyle(height: 1.5, fontWeight: FontWeight.bold),
                  ),
                  Text("Email: jumana.harun@gmail.com")
                ],
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => Personal_Info()));
              },
              child: Text(
                "Personal details",
                style: TextStyle(height: 1.5),
              ),
            ),
            SizedBox(
              height: 15,
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (context) => Skills()));
              },
              child: Text(
                "Skills",
                style: TextStyle(height: 1.5),
              ),
            ),
            SizedBox(
              height: 15,
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => Education()));
              },
              child: Text(
                "Education",
                style: TextStyle(height: 1.5),
              ),
            ),
            SizedBox(
              height: 15,
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => Experience()));
              },
              child: Text(
                "Experience",
                style: TextStyle(height: 1.5),
              ),
            )
          ],
        ),
      ),
    );
  }
}
