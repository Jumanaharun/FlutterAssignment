import 'package:flutter/material.dart';

class Skills extends StatelessWidget {
  const Skills({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("My Skills"),
      ),
      body: Column(
        children: [
          Text(
              "I'm a conscientious self-starter who is always keen on putting my critical-thinking and problem-solving skills to use, both in academic and real-life strategies. This makes me proficient in coding, especially c++ programming language. I can also grasp new concepts quicikly, therefore, I am able to learn new computer systems easily and get adaptable to new environment. Aside from Bangla, which is my native tongue, I'm also well versed in academic and spoken English.")
        ],
      ),
    );
  }
}
