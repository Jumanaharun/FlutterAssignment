import 'package:flutter/material.dart';

class Education extends StatelessWidget {
  const Education({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Education"),
      ),
      body: Column(
        children: [
          Text(
              "My education started with CBSE curriculum in an Indian school in Makkah, where I studied till grade 6. Later I shifted to a british curriculum school in Jeddah, where I completed my O-levels and A-levels. Currently, I'm studying in IIUC and my major is in CSE.")
        ],
      ),
    );
  }
}
