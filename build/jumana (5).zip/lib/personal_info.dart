import 'dart:html';

import 'package:flutter/material.dart';

class Personal_Info extends StatelessWidget {
  const Personal_Info({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Center(child: Text("My Personal info")),
        ),
        body: Column(
          children: [
            Text(
                "I was born and raised in Makkah, Saudi Arabia and I am of Bangladeshi descent. I'm based in Muradpur and my native hometown is Shatkania, Chattogram. In a family of 5, I have an older sister, who's in the same university as I am and a younger brother, who is in grade 11. My father used to be a school principal, now a business-man, and my mother a school teacher. In this modern era of information and advanced technologies, I'm obsessed with my social-media platforms, like Youtube videos, and therefore my hobby is to watch episodes or movies in my leisure time.")
          ],
        ));
  }
}
